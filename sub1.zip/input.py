import sys
from hello import *


def readinput(filename):
    roads = []

    lines = open(filename, "r").readlines()
    firstLine = lines[0].split(" ")
    D = int(firstLine[0])       # duration of simulation
    I = int(firstLine[1])       # number of intersections
    S = int(firstLine[2])       # Number of streets
    V = int(firstLine[3])       # number of cars
    F = int(firstLine[4])       # bonus points, trim of \n

    intersections = []
    for i in range(I):
        intersections.append(Intersection(i))

    for i in range(S):
        street = lines[i+1].split(" ")
        B = int(street[0])  # leaving intersection
        E = int(street[1])  # going to intersection

        streetName = street[2]
        L = int(street[3])  # length

        r = Road(B, E, L, streetName)
        roads.append(r)

        intersections[B].outgoing.append(r)
        intersections[E].incoming.append(r)

    for i in intersections:
        i.setupSchedule()

    return (intersections, roads)


def main():
    print("mad clever shit bro")
    graph = readinput("a.txt")  # g = (V,E)

    for i in graph[0]:
        i.debugOutput()

    WriteOutput(graph[0], "roughOutputA")


main()
