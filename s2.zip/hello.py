from output import *
import random
random.seed()

print("hello world")

squares = [i * i for i in range(20)]
alphabet = [x for x in 'abcdefghijklmnopqrstuvwxy']


class Road:
    def __init__(self, intersectionFrom, intersectionTo, lengthToPass, name):
        self.L = lengthToPass  # L value for this road
        self.From = intersectionFrom
        self.To = intersectionTo
        self.Name = name


class TrafficCommand:
    # no proper constructor because idk what to do
    def __init__(self, roadRelevantTo):
        self.Road = roadRelevantTo  # The road name
        # How long the lights are green for
        self.SecondsGreen = random.randint(1, 5)
        # sets it up as random for now


class Intersection:
    def __init__(self, intersectionNumber):
        self.intersectionNumber = intersectionNumber
        self.incoming = []  # Incoming roads
        self.outgoing = []  # Outgoing roads
        self.schedule = []  # List of TrafficCommand

    def setupSchedule(self):
        for income in self.incoming:
            command = TrafficCommand(income)
            self.schedule.append(command)

    def debugOutput(self):
        print("At intersection", self.intersectionNumber)
        print("Incoming roads: ")
        for i in self.incoming:
            print("\t" + i.Name)

        print("Outgoing roads: ")
        for i in self.outgoing:
            print("\t" + i.Name)
        print("-----")
